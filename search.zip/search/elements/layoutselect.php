<div class="lay-select-wr">
    <div class="menu-btn-lay"><button id="lay-sel-btn"><span>Layout</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="lay-sel"><ul class="menu-ul-sr-sm sel-lay-ul">
        <li class="sel-lay-li" data-val="" data-lang="lay-a">All layouts</li>
        <li class="sel-lay-li" data-val="Square" data-lang="lay-s">Square</li>
        <li class="sel-lay-li" data-val="Wide" data-lang="lay-w">Wide</li>
        <li class="sel-lay-li" data-val="Tall" data-lang="lay-si">Tall</li>
    </ul></div>
</div>

