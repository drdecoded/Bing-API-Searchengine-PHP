<div class="dura-select-wr">
    <div class="menu-btn-dura"><button id="dura-sel-btn"><span>Duration</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="dura-sel"><ul class="menu-ul-sr-sm sel-dura-ul">
        <li class="sel-dura-li" data-val="" data-lang="dur-a">Any length</li>
        <li class="sel-dura-li" data-val="Short" data-lang="dur-s">Short (less than 5 minutes)</li>
        <li class="sel-dura-li" data-val="Medium" data-lang="dur-m">Medium (5 to 20 minutes)</li>
        <li class="sel-dura-li" data-val="Long" data-lang="dur-l">Long (more than 20 minutes)</li>
    </ul></div>
</div>

