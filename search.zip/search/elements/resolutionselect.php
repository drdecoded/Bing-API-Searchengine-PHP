<div class="res-select-wr">
    <div class="menu-btn-res"><button id="res-sel-btn"><span>Resolution</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="res-sel"><ul class="menu-ul-sr-sm sel-res-ul">
        <li class="sel-res-li" data-val="" data-lang="re-a">Any resolution</li>
        <li class="sel-res-li" data-val="lowerthan_360p" data-lang="re-lt">Under 360p</li>
        <li class="sel-res-li" data-val="360p">360p +</li>
        <li class="sel-res-li" data-val="480p">480p +</li>
        <li class="sel-res-li" data-val="720p">720p +</li>
        <li class="sel-res-li" data-val="1080p">1080p +</li>
    </ul></div>
</div>


