<div class="region-select-wr">
    <div class="menu-btn-regiont"><button id="reg-sel-btn"><span>Suchregion</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
        <div class="reg-sel-reg"><ul class="menu-ul-sr-t sel-reg-ul">
        <li class="sel-reg-li" data-val="" data-lang="reg-all">All search regions</li>
        <li class="sel-reg-li" data-val="es-AR" data-lang="reg-ar">Argentina</li>
        <li class="sel-reg-li" data-val="en-AU" data-lang="reg-au">Australia</li>        
        <li class="sel-reg-li" data-val="de-AT" data-lang="reg-at">Austria</li>
        <li class="sel-reg-li" data-val="nl-BE" data-lang="reg-nl-be">Belgium(Dutch)</li>
        <li class="sel-reg-li" data-val="fr-BE" data-lang="reg-fr-be">Belgium(French)</li>
        <li class="sel-reg-li" data-val="pt-BR" data-lang="reg-br">Brazil</li>
        <li class="sel-reg-li" data-val="en-CA" data-lang="reg-ca-en">Canada(English)</li>
        <li class="sel-reg-li" data-val="fr-CA" data-lang="reg-ca-fr">Canada(French)</li>
        <li class="sel-reg-li" data-val="es-CL" data-lang="reg-cl">Chile</li>
        <li class="sel-reg-li" data-val="zh-CN" data-lang="reg-cn">China</li>
        <li class="sel-reg-li" data-val="da-DK" data-lang="reg-dk">Denmark</li>
        <li class="sel-reg-li" data-val="fi-FI" data-lang="reg-fi">Finland</li>
        <li class="sel-reg-li" data-val="fr-FR" data-lang="reg-fr">France</li>
        <li class="sel-reg-li" data-val="de-DE" data-lang="reg-de">Germany</li>
        <li class="sel-reg-li" data-val="zh-HK" data-lang="reg-hk">Hong Kong</li>
        <li class="sel-reg-li" data-val="en-IN" data-lang="reg-in">India</li>
        <li class="sel-reg-li" data-val="en-ID" data-lang="reg-id">Indonesia</li>
        <li class="sel-reg-li" data-val="it-IT" data-lang="reg-it">Italy</li>
        <li class="sel-reg-li" data-val="ja-JP" data-lang="reg-jp">Japan</li>
        <li class="sel-reg-li" data-val="ko-KR" data-lang="reg-kr">Korea</li>
        <li class="sel-reg-li" data-val="en-MY" data-lang="reg-mal">Malaysia</li>
        <li class="sel-reg-li" data-val="es-MX" data-lang="reg-mx">Mexico</li>
        <li class="sel-reg-li" data-val="nl-NL" data-lang="reg-nl">Netherlands</li>
        <li class="sel-reg-li" data-val="en-NZ" data-lang="reg-nz">New Zealand</li>
        <li class="sel-reg-li" data-val="no-NO" data-lang="reg-no">Norway</li>
        <li class="sel-reg-li" data-val="pl-PL" data-lang="reg-pl">Poland</li>
        <li class="sel-reg-li" data-val="en-PH" data-lang="reg-ph">Philippines</li>
        <li class="sel-reg-li" data-val="ru-RU" data-lang="reg-ru">Russia</li>
        <li class="sel-reg-li" data-val="en-ZA" data-lang="reg-za">South Africa</li>
        <li class="sel-reg-li" data-val="es-ES" data-lang="reg-es">Spain</li>
        <li class="sel-reg-li" data-val="sv-SE" data-lang="reg-se">Sweden</li>
        <li class="sel-reg-li" data-val="fr-CH" data-lang="reg-ch-fr">Switzerland(French)</li>
        <li class="sel-reg-li" data-val="de-CH" data-lang="reg-ch-de">Switzerland(German)</li>
        <li class="sel-reg-li" data-val="zh-TW" data-lang="reg-tw">Taiwan</li>
        <li class="sel-reg-li" data-val="tr-TR" data-lang="reg-tr">Turkey</li>
        <li class="sel-reg-li" data-val="en-GB" data-lang="reg-en-gb">English</li>
        <li class="sel-reg-li" data-val="en-US" data-lang="reg-en-us">United States(English)</li>
        <li class="sel-reg-li" data-val="es-US" data-lang="reg-es-us">United States(Spanish)</li>
    </ul></div>
</div>