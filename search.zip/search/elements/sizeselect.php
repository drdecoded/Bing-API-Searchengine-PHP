<div class="size-select-wr">
    <div class="menu-btn-size"><button id="size-sel-btn"><span>Size</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="size-sel"><ul class="menu-ul-sr-sm sel-size-ul">
        <li class="sel-size-li" data-val="" data-lang="si-a">All sizes</li>
        <li class="sel-size-li" data-val="Small" data-lang="si-s">Small</li>
        <li class="sel-size-li" data-val="Medium" data-lang="si-m">Medium</li>
        <li class="sel-size-li" data-val="Large" data-lang="si-l">Large</li>
        <li class="sel-size-li" data-val="Wallpaper" data-lang="si-w">Wallpaper</li>
    </ul></div>
</div>
