<div class="lic-select-wr">
    <div class="menu-btn-lic"><button id="lic-sel-btn"><span>License</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="lic-sel"><ul class="menu-ul-sr-sm sel-lic-ul">
        <li class="sel-lic-li" data-val="" data-lang="lic-a">All licenses</li>
        <li class="sel-lic-li" data-val="Public" data-lang="lic-acc">All Creative Commons</li>
        <li class="sel-lic-li" data-val="Any" data-lang="lic-pu">Public domain</li>
        <li class="sel-lic-li" data-val="Share" data-lang="lic-sh">Free to share and use</li>
        <li class="sel-lic-li" data-val="ShareCommercially" data-lang="lic-shc">Free to share and commercial use</li>
        <li class="sel-lic-li" data-val="Modify" data-lang="lic-mo">Free to modify, share and use</li>
        <li class="sel-lic-li" data-val="ModifyCommercially" data-lang="lic-moco">Free to modify, share and use commercially</li>
    </ul></div>
</div>
