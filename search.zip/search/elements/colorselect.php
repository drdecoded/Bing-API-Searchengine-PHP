<div class="color-select-wr">
    <div class="menu-btn-color"><button id="col-sel-btn"><span>Colors</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="col-sel"><ul class="menu-ul-sr-col sel-col-ul">
        <li class="sel-col-li sel-co-s" data-val=""><span data-lang="col-a">All colors</span></li>
        <li class="sel-col-li sel-co-s" data-val="ColorOnly"><span data-lang="col-oc">Colors only</span></li>
        <li class="sel-col-li sel-co-s" data-val="Monochrome"><span data-lang="col-bw">Monochrome</span></li>
        <div class="sel-col-md">
        <li class="sel-col-li sel-co" data-val="Black"><img src="src/public/icon-col-bla.png"><span data-lang="col-b">Black</span></li>
        <li class="sel-col-li sel-co" data-val="Gray"><img src="src/public/icon-col-gr.png"><span data-lang="col-g">Gray</span></li>
        <li class="sel-col-li sel-co" data-val="White"><img src="src/public/icon-col-w.png"><span data-lang="col-w">White</span></li>
        <li class="sel-col-li sel-co" data-val="Brown"><img src="src/public/icon-col-b.png"><span data-lang="col-br">Brown</span></li>
        <li class="sel-col-li sel-co" data-val="Blue"><img src="src/public/icon-col-bl.png"><span data-lang="col-bl">Blue</span></li>
        <li class="sel-col-li sel-co" data-val="Teal"><img src="src/public/icon-col-t.png"><span data-lang="col-bg">Teal</span></li>
        <li class="sel-col-li sel-co" data-val="Red"><img src="src/public/icon-col-r.png"><span data-lang="col-r">Red</span></li>
        <li class="sel-col-li sel-co" data-val="Orange"><img src="src/public/icon-col-o.png"><span data-lang="col-o">Orange</span></li>
        <li class="sel-col-li sel-co" data-val="Yellow"><img src="src/public/icon-col-y.png"><span data-lang="col-y">Yellow</span></li>
        <li class="sel-col-li sel-co" data-val="Green"><img src="src/public/icon-col-g.png"><span data-lang="col-gr">Green</span></li>
        <li class="sel-col-li sel-co" data-val="Purple"><img src="src/public/icon-col-p.png"><span data-lang="col-p">Purple</span></li>
        <li class="sel-col-li sel-co" data-val="Pink"><img src="src/public/icon-col-pi.png"><span data-lang="col-pi">Pink</span></li>
        </div>
    </ul></div>
</div>

