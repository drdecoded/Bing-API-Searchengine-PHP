<div class="time-select-wr">
    <div class="menu-btn-time"><button id="time-sel-btn"><span>Time</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="time-sel"><ul class="menu-ul-sr-sm sel-time-ul">
        <li class="sel-time-li" data-val="" data-lang="time-a">Current search results</li>
        <li class="sel-time-li" data-val="Day" data-lang="time-tf">Last 24 hours</li>
        <li class="sel-time-li" data-val="Week" data-lang="time-w">Last week</li>
        <li class="sel-time-li" data-val="Month" data-lang="time-m">Last month</li>
    </ul></div>
</div>


