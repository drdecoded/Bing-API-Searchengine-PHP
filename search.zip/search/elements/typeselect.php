<div class="typ-select-wr">
    <div class="menu-btn-typ"><button id="typ-sel-btn"><span>Typ</span></button><img class="down" src="src/public/icon-ar-down-bl.png"><img class="up" src="src/public/icon-ar-up-bl.png"></div>
    <div class="typ-sel"><ul class="menu-ul-sr-sm sel-typ-ul">
        <li class="sel-typ-li" data-val="" data-lang="ty-a">All types</li>
        <li class="sel-typ-li" data-val="Photo" data-lang="ty-ph">Photo</li>
        <li class="sel-typ-li" data-val="Clipart" data-lang="ty-cl">Clipart</li>
        <li class="sel-typ-li" data-val="Line" data-lang="ty-l">Line</li>
        <li class="sel-typ-li" data-val="AnimatedGifHttps" data-lang="ty-ani">Animated GIF</li>
        <li class="sel-typ-li" data-val="Transparent" data-lang="ty-tr">Transparent</li>
    </ul></div>
</div>
